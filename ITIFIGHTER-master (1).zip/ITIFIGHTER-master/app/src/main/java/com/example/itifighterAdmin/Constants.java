package com.example.itifighterAdmin;

public class Constants {
    public static final String STORAGE_PATH_UPLOADS = "uploads/";
    public static final String STORAGE_PATH_LOGOS = "menu/section/";
}
